const Story = require('../models/Story');

// Obtener todas las historias
exports.getAllStories = async (req, res) => {
  try {
    const stories = await Story.find().sort({ createdAt: -1 });
    res.json(stories);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener las historias' });
  }
};

// Crear una nueva historia
exports.createStory = async (req, res) => {
  try {
    const { placeName, lat, lon, tags } = req.body;
    const user = req.user?.email || 'anon';
    const imagePath = `uploads/${req.file.filename}`;

    const parsedLat = parseFloat(lat);
    const parsedLon = parseFloat(lon);

    if (isNaN(parsedLat) || isNaN(parsedLon)) {
      return res.status(400).json({ error: 'Latitud y longitud inválidas' });
    }

    const newStory = await Story.create({
      user,
      placeName,
      lat: parsedLat,
      lon: parsedLon,
      tags: tags ? tags.split(',').map(t => t.trim()) : [],
      imagePath,
    });

    res.status(201).json(newStory);
  } catch (err) {
    console.error('Error en createStory:', err);
    res.status(500).json({ error: 'Error al crear el spot' });
  }
};

// Actualizar una historia existente
exports.updateStory = async (req, res) => {
  try {
    const { id } = req.params;
    const { placeName, lat, lon, tags } = req.body;

    const parsedLat = parseFloat(lat);
    const parsedLon = parseFloat(lon);

    if (isNaN(parsedLat) || isNaN(parsedLon)) {
      return res.status(400).json({ error: 'Latitud y longitud inválidas' });
    }

    const updated = await Story.findByIdAndUpdate(
      id,
      {
        placeName,
        lat: parsedLat,
        lon: parsedLon,
        tags: tags ? tags.split(',').map(t => t.trim()) : [],
      },
      { new: true }
    );

    if (!updated) return res.status(404).json({ error: 'Spot no encontrado' });

    res.json(updated);
  } catch (err) {
    console.error('Error al actualizar el spot:', err);
    res.status(500).json({ error: 'Error al actualizar el spot' });
  }
};

// Eliminar un spot
exports.deleteStory = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await Story.findByIdAndDelete(id);
    if (!deleted) return res.status(404).json({ error: 'Spot no encontrado' });
    res.json({ message: 'Spot eliminado correctamente' });
  } catch (err) {
    console.error('Error al eliminar el spot:', err);
    res.status(500).json({ error: 'Error al eliminar el spot' });
  }
};

// Dar like a un spot
exports.likeStory = async (req, res) => {
  try {
    const { id } = req.params;
    const userEmail = req.user?.email;

    if (!userEmail) {
      return res.status(401).json({ message: "Usuario no autenticado" });
    }

    const story = await Story.findById(id);
    if (!story) {
      return res.status(404).json({ message: 'Spot no encontrado' });
    }

    if (story.likedBy.includes(userEmail)) {
      return res.status(400).json({ message: 'Ya diste like a este spot' });
    }

    story.likes = (story.likes || 0) + 1;
    story.likedBy.push(userEmail);
    await story.save();

    res.json({ likes: story.likes });
  } catch (error) {
    console.error('Error al dar like:', error);
    res.status(500).json({ message: 'Error interno del servidor' });
  }
};
