const mongoose = require('mongoose');

const storySchema = new mongoose.Schema({
  user: {
    type: String,
    required: true
  },
  placeName: {
    type: String,
    required: true
  },
  lat: {
    type: Number,
    required: true
  },
  lon: {
    type: Number,
    required: true
  },
  tags: {
    type: [String],
    default: []
  },
  imagePath: {
    type: String,
    required: true
  },
  likes: {
    type: Number,
    default: 0
  },
  likedBy: {
    type: [String], // Emails o IDs de usuarios que ya dieron like
    default: []
  }
}, {
  timestamps: true // Crea createdAt y updatedAt automáticamente
});

module.exports = mongoose.model('Story', storySchema);

